package WebDriverBascis;

import java.util.Arrays;

import java.util.List;

import java.util.concurrent.TimeUnit;



import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;

public class AddToCard {
	public static void main(String[] args) throws InterruptedException {

		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");



		WebDriver driver=new ChromeDriver();



		String[] itemsNeeded= {"Cucumber","Brocolli","Beetroot"};  //added list into one array of string


		driver.get("https://rahulshettyacademy.com/seleniumPractise/");

		Thread.sleep(3000);

		addItems(driver,itemsNeeded);

		}
	

		public static  void addItems(WebDriver driver,String[] itemsNeeded)

		{

		int j=0;

		List<WebElement> products=driver.findElements(By.cssSelector("h4.product-name"));
//takes all vegitables names  using find elements avaliable on website
		for(int i=0;i<products.size();i++) //get product size

		{

		//Brocolli - 1 Kg

		//Brocolli,    1 kg

		String[] name=products.get(i).getText().split("-"); //remove 1 kg by split

		String formattedName=name[0].trim();   //trim all spaces

		//format it to get actual vegetable name

		//convert array into array list for easy search

		//  check whether name you extracted is present in arrayList or not-

		List itemsNeededList = Arrays.asList(itemsNeeded);  //convert array into arraylist

		if(itemsNeededList.contains(formattedName))  //match array with given  product name

		{

		j++; //increase the count

		//click on Add to cart

		driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click(); //added to cart

		if(j==itemsNeeded.length) //if j count is equal to arraylist count then stop

		{

		break;

		}

		}

		}
}
}