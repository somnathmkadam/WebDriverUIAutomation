package WebDriverBascis;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class BasicFeatures {
	WebDriver driver;

	@Test
	public void basics() {
		//https://chromedriver.chromium.org/downloads chromedriver install accor to chrome version
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com/");
	System.out.println(driver.getTitle());	
	System.out.println(driver.getCurrentUrl());
//	System.out.println(driver.getPageSource());
	driver.findElement(By.xpath("//div[@id='searchform']/form/div[2]/div/div/div/div[2]/div/following-sibling::input")).sendKeys("Somnath");
	driver.findElement(By.xpath("//div[@id='searchform']/form/div[2]/div/div/div/div[2]/input")).clear();
	//     //div[@id='searchform']/parent::li
	
	//driver.get("https://www.yahoo.com/");
	//driver.navigate().back();
	//driver.navigate().forward();
	//driver.close(); //close current window
	//driver.quit(); //close all windows
	
		
	}
	
	
	
}
