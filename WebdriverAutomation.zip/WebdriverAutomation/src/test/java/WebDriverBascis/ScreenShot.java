package WebDriverBascis;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class ScreenShot extends Basetest {
	
	public static void main(String[] args) throws IOException  {
		// TODO Auto-generated method stub

		 

		DriverPath();
		//	driver.manage().window().maximize();
		//	driver.manage().deleteAllCookies();
		
		//	driver.manage().deleteCookieNamed("sessionKey");
		
		//click on any link
			//login page- verify login url
			
			
			driver.get("http://google.com");
			
			File src=	 ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src,new File("C:\\Users\\kadam.somnath\\screenshot.png"));
			//((TakesScreenshot)driver) called casting of TakesScreenshot with driver
			//we can used c directory directly so we can use user directory from c driver which is local directory
			//or else we can use c driver
		
		//	https://commons.apache.org/proper/commons-io/ download file utils jar
			//http://commons.apache.org/proper/commons-io/download_io.cgi
	}

}
