package WebDriverBascis;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;

public class SwitchingtoChild extends Basetest{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DriverPath();
driver.get("https://accounts.google.com/signup");

driver.findElement(By.xpath("//ul[@class='Bgzgmd']/li[3]/a")).click();
System.out.println(driver.getTitle());

Set<String> windows =driver.getWindowHandles();
                           
Iterator<String> ids=  windows.iterator();

             String parentId=      ids.next();
              String childid=     ids.next();
              driver.switchTo().window(childid);
              System.out.println(driver.getTitle());
	}

}
