package WebDriverBascis;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class FramesNdragNdrop extends Basetest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DriverPath();
		driver.get("https://jqueryui.com/droppable/");
		driver.switchTo().frame(driver.findElement(By.cssSelector("iframe.demo-frame")));
	WebElement source=	driver.findElement((By.id("draggable")));
	WebElement desti= driver.findElement(By.id("droppable"));
	
	Actions a = new Actions(driver);
	a.dragAndDrop(source, desti).build().perform();
		
	
	
	/*
	 * 
	 We can select frame by index:
Ex if there are two frames then 2 iframe tag should be present.
Find by syso(driver.findelement.by.tagname("iframe"));
Then 
driver.switchTo().frame(0); selects 1st frame and frame(1) will select 2nd frame
	 */
	
	}

}
