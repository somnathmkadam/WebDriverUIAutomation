package WebDriverBascis;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Basetest {
	static WebDriver driver;
	
	public static void DriverPath() {
	System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
	
	driver = new ChromeDriver();
	driver.manage().window().maximize();
}
}
