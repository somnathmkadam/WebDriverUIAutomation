package WebDriverBascis;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class LinkCountNScope extends Basetest{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DriverPath();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		System.out.println(driver.findElements(By.tagName("a")).size());
		WebElement minidriver = driver.findElement(By.cssSelector("table.gf-t"));
		
	System.out.println(minidriver.findElements(By.tagName("a")).size());	
	}

}
