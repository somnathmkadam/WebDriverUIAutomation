package WebDriverBascis;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class SelectSecondxpath extends Basetest {
	
	@Test
	public void selectsecXpath() throws InterruptedException {
	DriverPath();
		
		driver.get("https://www.spicejet.com/");
		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@value='PNQ']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//a[@value='BOM'])[2]")).click(); //second xpth is selected
		
		
		//parent child relationship
		driver.findElement(By.xpath("//div[@id='ctl00_mainContent_ddl_destinationStation1_CTNR'] //a[@value='PNQ']")).click();
	}

}
