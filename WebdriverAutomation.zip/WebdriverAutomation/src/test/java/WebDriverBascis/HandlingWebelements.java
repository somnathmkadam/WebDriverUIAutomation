package WebDriverBascis;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class HandlingWebelements extends Basetest {

	@Test
	public void dropdownHandle() throws InterruptedException {
		DriverPath();
		
		driver.get("https://www.spicejet.com/");
	//works only for select Tag	
	Select s = new Select(driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency")));
	s.selectByIndex(2);
	Thread.sleep(4000);
	//s.selectByValue("INR");
	//Thread.sleep(400);
//	s.selectByVisibleText("USD");

	
     driver.findElement(By.id("divpaxinfo")).click();
   Thread.sleep(4000);
     Select s1 = new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Adult")));
     s1.selectByIndex(6);
     Thread.sleep(4000);
     driver.findElement(By.id("divpaxinfo")).click();
  System.out.println(driver.findElement(By.id("divpaxinfo")).getText());   
     
 
     

	}
}
