package WebDriverBascis;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.annotations.Test;
@Test
public class FluentWaits extends Basetest {

	public void Wait(){
		DriverPath();
		driver.get("https://the-internet.herokuapp.com/dynamic_loading/1");
		driver.findElement(By.cssSelector("div[id='start'] button")).click();
	
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(3)).ignoring(NoSuchElementException.class); 
		
	//total timeot is 30 sec and poll- after 3 sec
		
		wait.until(new Function<WebDriver, WebElement>() {

			public WebElement apply(WebDriver driver) {
             
				if (driver.findElement(By.cssSelector("[id='finish'] h4")).isDisplayed()) //wait till text is getting displayed
		{
			return driver.findElement(By.cssSelector("[id='finish'] h4")); //return web element
		}

				
				
				return null; //otherwise return null
			}
			
			
			
			
		});
				
		System.out.println(driver.findElement(By.cssSelector("[id='finish'] h4")).getText());
		
	}
	
	
}
