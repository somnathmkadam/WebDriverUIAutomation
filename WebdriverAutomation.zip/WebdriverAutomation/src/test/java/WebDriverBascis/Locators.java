package WebDriverBascis;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Locators extends Basetest{
    @Test
	public void locators() {
        DriverPath();
        driver.get("https://www.facebook.com/");
        driver.findElement(By.id("email")).sendKeys("8652005324");
        driver.findElement(By.name("pass")).sendKeys("Mypassword");
        
      //  driver.findElement(By.linkText("Forgotten account?")).click(); //defined by anchore <a href
       //gettext used to get text on browser
       
       driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Somnath");
       driver.findElement(By.xpath("//*[@name='firstname']")).clear(); 
       driver.findElement(By.xpath("//*[contains(@aria-label,'First')]")).sendKeys("Sam"); //reqular expression
       driver.findElement(By.xpath("//table[@role='presentation']/tbody/tr[2]/td/input")).clear();
       driver.findElement(By.xpath("//table[@role='presentation']/tbody/tr[2]/td[2]/input")).clear();
       
       
       
        
        driver.findElement(By.cssSelector("#pass")).clear();
        driver.close();
    }
	
}
