package WebDriverBascis;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class OpenLinksInSeparateTabNGetLink extends Basetest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
            
		DriverPath();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		WebElement minidriver = driver.findElement(By.cssSelector("table.gf-t")); //main footer
		WebElement insideMini= minidriver.findElement(By.xpath("//table/tbody/tr/td/ul")); //first coloumn
		System.out.println(insideMini.findElements(By.tagName("a")).size()); //5 links present
	int count=	insideMini.findElements(By.tagName("a")).size();
	
	
		//Open each link in separate Tab
	
		for (int i=1;i<count;i++ ) {
	String	links=	Keys.chord(Keys.CONTROL,Keys.ENTER);  //press control+enter to open in separate tab
		
	insideMini.findElements(By.tagName("a")).get(i).sendKeys(links);//now click links using keyboard events
	Thread.sleep(5000);
		}
		
		
		Set<String> tabs=driver.getWindowHandles();
		Iterator<String> eachtab= tabs.iterator();//iterate string means separarte each tab link
		while(eachtab.hasNext()) { //run loop till tabs are present
			
			driver.switchTo().window(eachtab.next()); //switch driver to next tab
			System.out.println(driver.getTitle());    //get title
			
		}
		
		
	}

}
