package main;


import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.AutomationPratice;
import resources.BaseClass;

public class AutomationPracticePage extends BaseClass {
	
	
	@Test
	public void autoPractice() throws InterruptedException {
		
		
		AutomationPratice a = new AutomationPratice(driver);
		a.praticeProClick().click();
		a.radioButton(2).click();
		a.enterCountry().sendKeys("India");
		a.dropDown("option3");
		a.checkBox(3);
		a.alertText().sendKeys("Somnath");
		a.alertBut().click();
		a.alerthandle("gettext");
		System.out.println("Alert text is :"+a.gettext);
		try {
			Assert.assertEquals(true, a.gettext.contains("somnath".toLowerCase()),"Switch to alert example failed");
		}catch (AssertionError e) {
			e.printStackTrace();
	}
		
		a.alerthandle("accept");
		a.confirmBut().click();
		a.alerthandle("accept");
		
     	a.mouseHover("Reload");  
     	a.newwindow().click();
     	a.windowHandles("child");
     	a.hidetext().sendKeys("Madhukar");
     	a.tablePriceCount();
     	a.getlinks();
     //	a.iframe();
     	a.getLinkNClick(1);
     	a.MoveEachLink();
     	a.homePracticeProject();
     	a.practicProClick().click();
     	
     			
	
	}

}
