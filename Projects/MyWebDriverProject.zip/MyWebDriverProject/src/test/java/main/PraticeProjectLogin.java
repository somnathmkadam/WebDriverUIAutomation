package main;

import java.io.IOException;

import org.testng.annotations.Test;

import pageObjects.RahulShettyLogin;
import resources.BaseClass;

public class PraticeProjectLogin extends BaseClass {
	@Test
	public void rahulShetty() throws IOException {
		openBrowser();
		RahulShettyLogin login = new RahulShettyLogin(driver);
		login.getname().sendKeys("somnath");
		login.getemail().sendKeys("somkadam80@gmail.com");
		login.submit().click();

	}

}
