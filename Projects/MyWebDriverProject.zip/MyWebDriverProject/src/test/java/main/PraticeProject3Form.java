package main;

import java.io.IOException;

import org.testng.annotations.Test;

import pageObjects.AutomationForm;
import resources.BaseClass;

public class PraticeProject3Form extends BaseClass{
	@Test
	public void Praticeproject() throws IOException {
		driver=initalizeDriver();
		driver.manage().window().maximize();
		driver.get("https://rahulshettyacademy.com/angularpractice/");
		AutomationForm form = new AutomationForm(driver);
		form.calender("1/1/2019");
		form.getName().sendKeys("Somnath Kadam");
		form.getEmail().sendKeys("Somkadam8080@gmail.com");
		System.out.println("value in email field is :"+ form.getEmail().getAttribute("value"));
		form.getPassword().sendKeys("somkadam");
		form.getCheckbox().click();
		form.dropDown("Female");
		form.checkbox("Employed");
		form.getSubmit().click();
		form.verifytext();
		
	}
	
	
	

}
