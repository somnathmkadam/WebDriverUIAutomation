package main;

import java.io.IOException;
import java.util.Map;

import org.testng.annotations.Test;

import pageObjects.AutomationForm;
import resources.BaseClass;
import resources.DataAccess;
import resources.DataProviderUtil;

public class PraticeProjectFormUsingDataprovider extends BaseClass {

	
	@Test(dataProvider="TestData",dataProviderClass= DataProviderUtil.class)
	public void dataaccess(String data) throws IOException {
		
		DataAccess dataconvert = new DataAccess();
		Map<String, String> actualdata=dataconvert.dataConverter(data);
		driver=initalizeDriver();
		driver.manage().window().maximize();
		driver.get("https://rahulshettyacademy.com/angularpractice/");
		AutomationForm form = new AutomationForm(driver);
		form.getName().sendKeys(actualdata.get("name"));
		form.getEmail().sendKeys(actualdata.get("email"));
		driver.close();
		
	}
	
}
