package main;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.codec.language.bm.Rule.Phoneme;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AngularPracticePage {

	@SuppressWarnings("null")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("https://rahulshettyacademy.com/angularpractice/shop");

		WebElement element = driver.findElement(By.xpath("//a[@class='carousel-control-prev']/span"));
		element.click();
		String[] phonenames = { "iphone", "samsung", "nokia" };
		String[] phonenames2 = { "iphone=0", "samsung=2", "nokia=2" };
		// List<String> lists = new ArrayList<String>();
		List<WebElement> names = driver.findElements(By.xpath("//div[@class='col-lg-9']//div[@class='card-body']/h4"));
		List<WebElement> button = driver.findElements(By.xpath("//div[@class='card-footer']/button"));
		for (int i = 0; i < names.size(); i++) {
			String phonenamefetch = names.get(i).getText().trim();
			// lists.add(names.get(i).getText());
			for (int a1 = 0; a1 < phonenames.length; a1++) {
				boolean value = phonenamefetch.toLowerCase().contains(phonenames[a1]);
				if (value) {
					button.get(i).click();
					break;
				}

			}
		}
		driver.findElement(By.cssSelector("[class='nav-link btn btn-primary']")).click();

		ArrayList<String> abc = new ArrayList<String>();
		List<WebElement> nextpaname = driver.findElements(By.cssSelector("[class='col-sm-8 col-md-6'] h4 a"));
		List<WebElement> nextpaname1 = driver.findElements(By.xpath("//input[@id='exampleInputEmail1']"));
		String phoname;
		for (int a = 0; a < phonenames2.length; a++) {
			String[] newarray = phonenames2[a].split("=");
			int x = 0;
			int i = 0;
			while (i < nextpaname.size()) {

				String numberinc = nextpaname1.get(i).getAttribute("value");
				int y = Integer.parseInt(numberinc);
				if (x == y) {
					break;
				}
				phoname = nextpaname.get(i).getText();
				boolean values1 = phoname.toLowerCase().contains(newarray[0]);
				if (values1) {
					nextpaname1.get(i).click();
					String valuetoinc = newarray[1];
					x = Integer.parseInt(valuetoinc);
					for (int i2 = 0; i2 < x; i2++) {
						nextpaname1.get(i).sendKeys(Keys.ARROW_UP);
					}
				}
				i++;

			}

			// System.out.println("List of phone names avaliable on page is :" + lists);

			// driver.close();

		}

	}
}