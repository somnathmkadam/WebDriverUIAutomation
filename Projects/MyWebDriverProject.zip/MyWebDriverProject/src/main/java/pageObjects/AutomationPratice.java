package pageObjects;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.SendKeys;
import org.openqa.selenium.support.ui.Select;

public class AutomationPratice {

	public WebDriver driver;

	public AutomationPratice(WebDriver driver) {

		this.driver = driver;
	}

	By pratice2 = By.xpath("//a[contains(text(),'Automation Practise - 2')]");
	By name = By.xpath("//h1[text()='Practice Page']");
	By radio1 = By.cssSelector("value='radio1']");
	By radio3 = By.cssSelector("value='radio3']");
	By country = By.id("autocomplete");
	By dropDown = By.name("dropdown-class-example");
	By checkBox = By.cssSelector("label[for='benz'] input");
	By alerttext = By.cssSelector("[name='enter-name']");
	By alertbut = By.id("alertbtn");
	By confirm = By.id("confirmbtn");
	By mousehover = By.id("mousehover");
	By newwindow = By.id("openwindow");
	By newtab = By.linkText("Open Tab");
	By hidetext = By.id("displayed-text");
	By getlinks = By.cssSelector("[class='gf-t']");
	By practiceProject = By.linkText("Practice Projects");

	public WebElement practicProClick() {
		return driver.findElement(practiceProject);
	}

   //Get all links count avaliable on footer	
	public WebDriver getlinks() {
		WebElement mini = driver.findElement(getlinks);
		int links = mini.findElements(By.tagName("a")).size();
		System.out.println("Total links avaliable :" + links);
		return driver;
	}

	// Click on each link
	public void getLinkNClick(int num) {
		By openlinks = By.xpath("//table[@class='gf-t']/tbody/tr/td[1]");
		WebElement minidriver = driver.findElement(openlinks);
		int count = minidriver.findElements(By.tagName("a")).size();
		for (int i = 1; i < count; i++) {
			minidriver.findElements(By.tagName("a")).get(i).sendKeys(Keys.CONTROL, Keys.ENTER);

		}
	}

	// Open Each link in separate tab and Goto Each tab and then move to default
	// page
	public void MoveEachLink() {
		String parent = driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> count = windows.iterator();
		System.out.println("Total links open are  :" + windows.size());
		System.out.println("Total links are given below: ");
		while (count.hasNext()) {
			driver.switchTo().window(count.next());
			System.out.println(driver.getTitle());
            driver.close();
		}
		driver.switchTo().window(parent);
	}

	// CLick on Home Button
	public void homePracticeProject() {
		driver.findElement(By.xpath("//header[@class='jumbotron text-center header_style']/div/a/button")).click();
	}

	// Enter text in hidetext area
	public WebElement hidetext() {
		return driver.findElement(hidetext);
	}

	public WebElement newtab() {
		return driver.findElement(newtab);
	}

	public WebElement newwindow() {
		return driver.findElement(newwindow);
	}

	public WebElement enterCountry() {
		return driver.findElement(country);

	}

	public WebElement checkBox(int number) {

		WebElement checkbox = driver
				.findElement(By.xpath("//div[@id='checkbox-example']/fieldset/label[" + number + "]/input"));
		return checkbox;
	}

	public Actions mouseHover(String value) {
		Actions a = new Actions(driver);
		a.moveToElement(driver.findElement(mousehover)).click().perform();
		a.click(driver.findElement(By.linkText(value))).perform();
		;
		return a;

	}

	public WebElement praticeProClick() {
		return driver.findElement(pratice2); // click on Automation Practise - 2
	}

	public WebElement radioButton(int number) {

		WebElement radiobutton = driver
				.findElement(By.xpath("//div[@id='radio-btn-example']/fieldset/label[" + number + "]/input"));
		return radiobutton;
	}

	public Select dropDown(String value) {

		Select s = new Select(driver.findElement(dropDown));
		s.selectByValue(value);
		return s;
	}

	public WebElement alertBut() {
		return driver.findElement(alertbut);
	}

	public WebElement alertText() {

		return driver.findElement(alerttext);
	}

	public WebElement confirmBut() {
		return driver.findElement(confirm);
	}

	public String gettext = null;

	public void alerthandle(String data) {
		Alert alert = driver.switchTo().alert();
		if (data == "accept") {
			alert.accept();
		}

		else if (data == "dismiss") {
			alert.dismiss();
		}

		else if (data == "gettext") {
			gettext = alert.getText().toLowerCase();

		}
	}

	public WebDriver iframe() throws InterruptedException {

		// WebDriver
		// driver1=driver.switchTo().frame(driver.findElement(By.cssSelector("iframe#courses-iframe")));
		// Thread.sleep(2000);
		// WebElement element= driver.findElement(By.linkText("About"));
		driver.switchTo().frame("courses-iframe");
		System.out.println("Driver: " + driver.findElement(By.tagName("title")).getText());
		driver.findElement(By.linkText("About")).click();
		System.out.println(driver.getCurrentUrl() + " " + driver.getTitle());
		// driver1.findElement(By.linkText("About")).click();
		driver.switchTo().defaultContent();
		return driver;

	}

	public WebDriver windowHandles(String id) {
		String mainWindow = driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> windowid = windows.iterator();
		String parentid = windowid.next();
		String childid = windowid.next();
		/*
		 * while(windowid.hasNext()){ String childWindow=windowid.next();
		 * if(!mainWindow.equals(childWindow)){ driver.switchTo().window(childWindow);
		 * System.out.println(driver.switchTo().window(childWindow).getTitle());
		 * driver.close(); }
		 * 
		 * }
		 */
		String value = "child";
		driver.switchTo().window(childid);
		if (id.equalsIgnoreCase(value)) {
			childWindowPopup();
			driver.close();

		} else {
			driver.switchTo().window(childid);
			driver.close();

		}
		driver.switchTo().window(parentid);
		return driver;
	}

	public WebDriver childWindowPopup() {
		By path = By.xpath("//div[@class='sumome-react-wysiwyg-move-handle'] //button[contains(text(),'NO THANKS')]");
		List<WebElement> popup = driver.findElements(path);
		// WebElement element=driver.findElement(path);

		System.out.println("Size is :" + popup.size());
		if (popup.size() > 0) {
			driver.findElement(path).click();
		}
		return driver;

	}

	public void tablePriceCount() {
		WebElement tabledriver = driver.findElement(By.id("product"));

		int totalrows = tabledriver.findElements(By.tagName("tr")).size();
		Iterator<WebElement> table = tabledriver.findElements(By.tagName("tr")).iterator();
		System.out.println("Total count is :" + totalrows);
		System.out.println("Prices and its total count is given below  :");

		/*
		 * while(table.hasNext()) { i++; String price=
		 * driver.findElement(By.xpath("//table[@id='product']/tbody/tr["+i+"]/td[3]")).
		 * getText(); System.out.println("price  :\n"+ price);
		 */

		int totalprice = 0;
		for (int i = 2; i - 1 < totalrows; i++) {
			String price = driver.findElement(By.xpath("//table[@id='product']/tbody/tr[" + i + "]/td[3]")).getText();
			System.out.println("price  :\n" + price);

			int prices = Integer.parseInt(price.trim());
			totalprice = prices + totalprice;
		}
		System.out.println("Total price is :" + totalprice);

	}

}
