package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;

import org.apache.http.conn.ssl.BrowserCompatHostnameVerifier;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;


public class AutomationForm {

	public WebDriver driver;
	private WebElement name;
	private WebElement email;
	private WebElement password;
	private WebElement checkbox;
	private WebElement staticdropdown;
	private WebElement submit;
	private WebElement checktwowaybinding;

	public AutomationForm(WebDriver driver) {

		this.driver = driver;
		name = this.driver.findElement(By.name("name"));
		email = this.driver.findElement(By.name("email"));
		password =this.driver.findElement( By.id("exampleInputPassword1"));
		checkbox = this.driver.findElement(By.id("exampleCheck1"));
		staticdropdown = this.driver.findElement(By.id("exampleFormControlSelect1"));
		submit = this.driver.findElement(By.cssSelector("[class='btn btn-success']"));
	//	checktwowaybinding =this.driver.findElement(By.xpath("//input[@class='ng-valid ng-touched ng-dirty']"));
	}
             
	                    
	public WebElement getName() {
		return name;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getPassword() {
		return password;
	}

	public WebElement getCheckbox() {
		return checkbox;
	}


	public WebElement getSubmit() {
		return submit;
	}

	public WebElement getChecktwowaybinding() {
		return checktwowaybinding;
	}

	public void dropDown(String value) {

		staticdropdown.click();
		while(!staticdropdown.getText().equalsIgnoreCase(value.trim())) {
		staticdropdown.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
		break;
		}
		
	}
	

	public void checkbox(String name) {

		if (name.equalsIgnoreCase("Student")) {
			 driver.findElement(By.cssSelector("[value='option1']")).click();
		}

		else if (name.equalsIgnoreCase("Employed")) {
			 driver.findElement(By.cssSelector("[value='option2']")).click();
		}

		else if (name.equalsIgnoreCase("Entrepreneur")) {
			 driver.findElement(By.cssSelector("[value='option3']")).click();
		}
		

		
	}

	public void verifytext() {
		By path =By.xpath("//div[@class='container']/h4/input");
		String element =driver.findElement(By.xpath("//div[@class='container']/h4/input")).getAttribute("value");
		
		
		System.out.println("entered text is :"+element);
	}
	
	
	public void calender(String date) {
		driver.findElement(By.cssSelector("[type='date']")).click();
		ArrayList<String> mylist = new ArrayList<String>();
	String [] newdate=	date.split("/");
	for (String a : newdate) {
		if(a.length() <2) {
			
			     a="0"+a;
				 mylist.add(a);
				System.out.println("new date is   "+mylist);
			     
	
		}
		else if(a.length()==2) {
			mylist.add(a);	
		}
		else if(a.length()>3) {
			mylist.add(a);
		}
	
}

String abc= String.join("/", mylist);
driver.findElement(By.cssSelector("[type='date']")).sendKeys(abc);

	}
	
}
