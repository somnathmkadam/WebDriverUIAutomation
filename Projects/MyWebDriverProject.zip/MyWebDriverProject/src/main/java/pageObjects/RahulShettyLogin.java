package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RahulShettyLogin {

	public WebDriver driver;

	public RahulShettyLogin(WebDriver driver) {

		this.driver = driver;
	}

	By name = By.id("name");
	By email = By.name("email");
	By submit = By.cssSelector("button[type='submit']");
	

	public WebElement getname() {

		return driver.findElement(name);
	}

	public WebElement getemail() {

		return driver.findElement(email);
	}

	public WebElement submit() {

		return driver.findElement(submit);
	}

}
