package resources;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderUtil {
	
	
	@DataProvider(name = "TestData")
	public static Object[][] dataprovider() {
		return new Object[][] {{"name:somnath,email:somnathkadam@gmail.com"},{"name:sam,email:abc@gmail.com"},{"name:abc,email:sham@gmail.com"}};
	}
	
	//@DataProvider(name="textfiledata")
	@Test
	public static String dataprovider1() throws IOException{
		File file = new File("D:\\Eclipse\\MyWebDriverProject\\sample.txt"); 
		  
		  BufferedReader br = new BufferedReader(new FileReader(file)); 
		  
		  String st; 
		  while ((st = br.readLine()) != null) 
		    System.out.println(st); 
		return st;
		
	}

}
