package resources;

import java.util.HashMap;
import java.util.Map;



public class DataAccess {
	
	
	public Map<String, String> dataConverter(String data) {
		String []arrays= data.split(",");
		Map<String, String> mapper = new HashMap<String, String>();
		for(int i=0;i<arrays.length;i++) {
			String[] values = arrays[i].split(":");
			mapper.put(values[0], values[1]);
		}
		return mapper;
	}
	
		
	}
	
	

