package resources;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;

public class BaseClass {
	public static WebDriver driver;
	public Properties property;
     
	public WebDriver initalizeDriver() throws IOException {

		property = new Properties();
		String path = System.getProperty("user.dir");
		FileInputStream file = new FileInputStream(path + "\\src\\main\\java\\resources\\data.properties");
		property.load(file);
		String browser = property.getProperty("browser");

		System.out.println("------------------------------------------------------------------------------");
		System.out.println("Broswer is  :" + browser);
		System.out.println("-------------------------------------------------------------------------------");

		if (browser.equalsIgnoreCase("chrome")) {

			System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
			driver = new ChromeDriver();
		}

		else if (browser.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
			// firefox code
		}

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return driver;

	}

	public void openBrowser() throws IOException {

		driver = initalizeDriver();
		driver.manage().window().maximize();
		driver.get(property.getProperty("url"));

	}

	public void getScreenshot(String result) throws IOException {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C://test//" + result + "screenshot.png"));

	}

	public void closeBrowser() {
		driver.close();
	}
	
	
	
		

}
