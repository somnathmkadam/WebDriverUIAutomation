package Http;

import java.util.Scanner;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.impl.client.HttpClients;

public class sam1 {
	public static void main(String args[]) throws Exception{
		
	HttpClient client = HttpClients.custom().build();
	HttpUriRequest request = RequestBuilder.get()
	  .setUri("http://www.tutorialspoint.com/")
	//  .setHeader(HttpHeaders.CONTENT_TYPE, "application/json")
	  .build();
	HttpResponse response= client.execute(request);
Scanner sc = new Scanner(response.getEntity().getContent());
	
	System.out.println(response.getStatusLine());
    //while(sc.hasNext()) {
    //   System.out.println(sc.nextLine());
   // }
	}
}
