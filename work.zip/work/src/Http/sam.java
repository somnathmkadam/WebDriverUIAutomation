package Http;

import java.util.Scanner;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class sam {
	public static void main(String args[]) throws Exception{
		
		
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpGet httpget = new HttpGet("https://flight.yatra.com/air-search-ui/dom2/trigger?type=O&viewName=normal&flexi=0&noOfSegments=1&origin=DEL&originCountry=IN&destination=BOM&destinationCountry=IN&flight_depart_date=12%2F02%2F2020&ADT=1&CHD=0&INF=0&class=Economy&source=fresco-home");
		HttpResponse httpresponse = httpclient.execute(httpget);
		Scanner sc = new Scanner(httpresponse.getEntity().getContent());
		
		System.out.println(httpresponse.getStatusLine());
	    while(sc.hasNext()) {
	     System.out.println(sc.nextLine());
		
	       
	    }
		}
	}
