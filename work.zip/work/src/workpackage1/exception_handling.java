package workpackage1;

public class exception_handling {
	/*
	 compile time error
	 run time error
	 
	1. Compile time error: error in compilation not given , : ; or anything so at the time of compilation .class file has not been created
	2. Run time error: program terminate while running program so interpreter create an object and throws an exception 
	 */

}



