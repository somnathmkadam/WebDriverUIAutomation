package workpackage;

public class Static {
	
	
	/*
	 if you want to access variables and methods from one class without creating any object then 
	 you can use static methods and variables
	 In normal instance variable or method when we instantiate it by creating object in another class it will create copy of that 
	 variable or methods means result or changes in each object are different
	 but if we use static method then changes in one class will reflect in all classes
	 we cannot use this or super in class having static method or variable
	 
	 */

	static int x=10;   //static class variable
	
	static int cube (int y) // static method
	{
		return (y*y*y);
	}
	
	int c;
	int a=6; //instance variable
	
	void cube1(int b)  // instance method
	{
		c=b;
		System.out.println("instance method value "+c);
		System.out.println("value of a" + a);
	}
	
}
