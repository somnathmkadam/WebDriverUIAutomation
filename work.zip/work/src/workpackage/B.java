package workpackage;

public interface B {

	void numberofB(); // implement in interface class
	
}
