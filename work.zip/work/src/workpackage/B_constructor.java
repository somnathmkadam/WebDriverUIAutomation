package workpackage;

public class B_constructor extends A__constructor {
	// check main constructor
	
	// using super keyword we can call constructor is immediate super class constructor in normal if constructor is not 
	//Parameterized then constructor is been called implicitly in subclass constructor (No need to write super();
	// but if want to write it explicitly then write it in first row of constructor in sub class
	

	public B_constructor() {
		// TODO Auto-generated constructor stub
		// here super class constructor called implicitly
		System.out.println("Constructor in class B");
	}
}
