package workpackage;

public class Methodoverloading_main {

	public static void main(String args[]) {
		MethodOverloading obj = new MethodOverloading();
		obj.calculation(10);
		obj.calculation(10, 20);
		
	}
	
}

