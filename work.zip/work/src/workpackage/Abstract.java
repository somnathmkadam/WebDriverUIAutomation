package workpackage;

abstract class Abstract {

	/* abstract used to when you want all related method in one class 
	  and you can define them in different classes.
	  1. if your class is abstract there may or may not any abstract method
	  2. if your class contains any abstract method then that class must be abstract class
	  3. you cannot inherited or can't make object of abstract class
	  4. you can make subclass of abstract class (using extends) after that you can used abstract 
	  class and subclass by making object of subclass in another class
	  5. in your subclass which extends of abstract class you have to define all methods used in 
	  Abstract class
	  6. You can define abstract methods in different subclasses also
	  7. abstract method contain normal as well as abstract class

	 */
	
	abstract void disp();  // in abstract method you cannot define means { }
	void abcd () {
		
	System.out.println("normal method in abstract class 1"); // normal method define syso
	}
	
	abstract void view(); //you can crate many abstract class 
	abstract void disp1();
	
	
	
}
