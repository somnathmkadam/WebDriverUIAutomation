package workpackage;

public interface Sport {  //check student class
  int SP =10;
  void spmarks();
	
	
}
