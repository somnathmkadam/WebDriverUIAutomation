package workpackage;

public class Packages_AccessModifiers {
	
	/*
	1.  Build in packages/pre-defined : java.io , java.lang, java.util.scanner, java.awt --- java is package and util is subpackage and scanner is class. 
	 subpackage can contain many classes
	2. user define packages: must be unique, lower case letter used, 
	class: first letter capital ex: Sample, method: dispName, 
	 Adv of packages: reusability- can be used in many classes, access control: hidden class  private, protected can not be used outside of packages
	 , class name can be same in two different packages
	 
	 *-----> accessing packages: A. fully qualified class name, B. Import statement
	 A. fully qualified class name: Ex: in one package containes a, b and c class and we want to access it another package: so 
	 ex: we create object in another class : pack.A obj = new pack.A(); -------- pack is package name
	 
	 to import all classes from package we use: import packagename.*;    -- but not used in subpackages
	 to used perticular class : import packagename.classname;
	
	 */

	
	/*
	 Access Modifiers: if we use private to particular variable then use cannot use it another class using inheritence/ extends
	* class level: public, default-- also called package private (cant use it another packages) or friendly for default no need to write anything
	  but if we use public keyword to class then we can use it any package
	 rules: in source code we can create only one class public and to save program we have to give name classname ex: a class to save program we use a.java
	 
	 
	 for variables and methods access modifiers are: public, private, protected, default, private protected
	 public: can be used any class or packages
	 protected: can be used within package to used it outside the package use inheritance (extends)
	 private: can be use within class only (even if inheritance used)
     default: can be used within package (even if inheritance used)
     private protected: can be used in subclasses only (Extends) any package
     
     
     
     	 
	 Package:
	 package name should be in lower case only
	 in main program there can be only one class in public and you have to save program with that classname 
	 
	 to access class from subpackage in main package we have to write import.pack1name.pack2name.* if we write import.pack1.* then we can access class in main
	 package only
	  
	 
	 
	 */
	
	
}
