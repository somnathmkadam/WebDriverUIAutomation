package workpackage;

public class Super_Subclass extends Super_Class {
int num;

public Super_Subclass(int a, int b) {
	// TODO Auto-generated constructor stub
	
	num = a;
	super.num=b;	

}
	void message() {
		System.out.println("message in subclass "+num);
	}
	
	void display() {
		message();
		super.message();
	}
	
}
