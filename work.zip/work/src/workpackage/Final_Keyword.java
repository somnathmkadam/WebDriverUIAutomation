package workpackage;

public class Final_Keyword {


	/*
	 we can use final keyword to variable, classes, method.
	 There are three variable types : instance variable: which used in any class, class variable: in we add static keyword 
	 to variable then it will become as class variable, local variable: if we used any variable inside method then it will 
	 become local variable.
	 if you assign value to any static variable then you cant change the value in same class or in any other sub class
	 ex: count=100; then count= count+ 10 is not allowed
	 if you assign static keyword to any class then you cant inherited means extend that class
	 
	 */
	final int Count=100;  //instance variable
// b= count+10 you can use it like this
	
	static final int count1=10; // class variable
	// or we can use static block to assign the value
	
	static final int count2;
	static {
		count2=50; //static block
	}
	
	
	final int count3; // instance variable value can be assigned in constructor
	public Final_Keyword(){
		count3=10;  // constructor
	}
	
	void disp() {  
		final int count4=10;  // final in method called local variable
		//or
		final int count5;
		count5=20;
	}
	
	void disp1(final int x) {
	// assign final to parameterized method 
	}
	
	
	final void abcd() { //assign final keyword to method we can use this method in any class but we cannot override the method
		
	}
	
	
	//final class1 xx() {}  assigning final keyword to class we can inherited that class means extends
		
	
	
	}
	
	
	
	
	

