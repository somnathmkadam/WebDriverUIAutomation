package workpackage;

public class B_para_constructor extends A_para_Constructor { //check main_para_constructor
int B;

public B_para_constructor(int z, int y) {
	// TODO Auto-generated constructor stub
	super(y); //calling super class constructor
	B=z;
	System.out.println("value of b sub "+B);
	
}
	
	
	
}
