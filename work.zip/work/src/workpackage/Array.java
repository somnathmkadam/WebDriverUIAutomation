package workpackage;

import java.util.Scanner;

public class Array {
/*
 declaration of array:
 type arrayname[];  --- int roll[];
 type [] arrayname;
 
 creation of array:
 arrayname = new type [size];
 ex: roll = new int [5];  --- created 5 locations for this array start from zero
 
 combine form:
 type arrayname[]=new type size[];
 ex: int roll[]= new int [5];
 
 Initialization of array:
 type arrayname[]={list of array} -- here no need to  write new because required memory location is created automatically
 ex: int roll[]= {10,20,30,40}
 
  
  array using for loop:
  for (int i=0; i<5; ; i++)
  {
  roll [i]=i;  ------[i] is subscript 
  }
  
  we can user subscript directly into calculations:
  roll[3]= roll[0]+roll[1];
  
  array length:
  to check lenth of any array:
  int x= roll.length;
  syso("array length "+x);
 
 
 */
	
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in); //system is class which gives input from user where sc is object
		System.out.println("Enter size");
		int n = sc.nextInt();  //take size from user stored in n 
		int marks[] = new int[n]; // created array size given by user
		
		System.out.println("array length is "+ marks.length); //array lenth shown
		System.out.println("enter "+ n +"elements"); 
		
		for (int i=0; i<marks.length; i++) {
			
			marks[i]= sc.nextInt(); //nextIn is method so second word start with capi letter
		}
		
		//to show stored value on screen plus total of all values we use for loop 
		int total = 0;
		System.out.println("Elemments are given below");
		for (int i=0; i<marks.length; i++) {
			System.out.println(marks[i]);
			total = total+marks[i];
			
		}
		System.out.println(" and total is "+ total);
		
		
		
		
		
		
	}
	
}
