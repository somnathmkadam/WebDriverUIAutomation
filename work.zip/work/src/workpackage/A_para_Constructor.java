package workpackage;

public class A_para_Constructor {

	
	int A;
	
	public A_para_Constructor(int x) {
		// TODO Auto-generated constructor stub
		A=x;
		System.out.println("value of A super "+ A);
	}
	
}
