package workpackage;

public class A__constructor {
	
	//calling constructor using super keyword check class b constructor
	public A__constructor() {
		// TODO Auto-generated constructor stub
		System.out.println("Constructor in class A");
	}

}
