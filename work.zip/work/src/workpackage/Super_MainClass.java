package workpackage;

public class Super_MainClass {
	
	public static void main(String args[]) {
		Super_Subclass obj = new Super_Subclass(10, 20);
		obj.display();
		
	}
	
}
