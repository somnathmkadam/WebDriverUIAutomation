package workpackage;

public class Super_Class {
	
	int num;
	
	void message() {
		System.out.println("message in super class value "+ num);
		
	}

}
