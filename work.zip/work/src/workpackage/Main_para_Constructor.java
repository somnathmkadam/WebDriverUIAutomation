package workpackage;

public class Main_para_Constructor {
	public static void main(String args[]) {
		B_para_constructor obj = new B_para_constructor(20, 30);
	}

	
}
