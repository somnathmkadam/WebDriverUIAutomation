package workpackage;

 class interface_Main {

	public static void main (String args[]) {
		
		Interface obj= new Interface();
		
		obj.number();
		obj.numberofB();
		
	}
	
	
}
