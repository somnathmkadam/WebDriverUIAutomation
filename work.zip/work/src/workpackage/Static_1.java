package workpackage;

public class Static_1 {

	int result = Static.x=20;

	
	Static obj = new Static(); // you cannot access using object in normal class means for obj. not showing anything
	
	
	
	
	
}
