package workpackage;

class Result extends Student implements Sport {  // used in testofresult class

	
	public void spmarks() {
		System.out.println("marks is "+ SP);
	}
	
	void disp() { // function
		putmarks();
		spmarks();
		int total = m1+m2+SP;
		System.out.println(" total marks is "+ total);
	}
	
	
}
