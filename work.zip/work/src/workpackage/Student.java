package workpackage;

public class Student {   //used in result class for multiple inheritance and we used sport class

	int m1, m2;
	void getmark(int x1, int x2) {
		m1=x1;
		m2=x2;
	
	}
	
	void putmarks() {
		System.out.println("first rank "+ m1);
System.out.println(" second rank "+ m2);

	}
	
	
}
