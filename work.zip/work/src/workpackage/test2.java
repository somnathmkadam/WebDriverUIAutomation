package workpackage;

 class test2 {
public static void main(String args[]) {
	test1 obj = new test1(); //test1 is default constructor because we have not specified this constructor in any class ex: in test1
	obj.getdata(100, 200);
	obj.add();
} 
}
