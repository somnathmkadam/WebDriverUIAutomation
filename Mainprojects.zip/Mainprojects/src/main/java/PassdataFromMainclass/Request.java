package PassdataFromMainclass;

import static io.restassured.RestAssured.given;

import PassBodythroughanotherclas.Bodypassinrestrequest;

public class Request {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		String response = given().header("Device-Id","b73d13743966d9cd")
				 .header("yt-code","898cca20b1066c2621c4ee78d5f32850")
				.header("Parent-Interaction-Id","8ec43f34-6ef8-492d-bcf4-f5931fc1e4fe")
				.header("Connection","close")
				.header("User-Agent","yatra/13.0.95 (Android 9)")
				.header("App-Version","399")
	           .header("secure-s-token","1b99a635-f77f-4ff4-b35c-4870725e97a9")  
	           .header("Session-Id","b73f13743966d9cd15856541327545467")
	           .header("Content-Type","application/x-www-form-urlencoded")
	           .body(Body.body("GUEST","city"))
	           .when().post("ccwebapp/mobile/hotel/mdomhotelandroid/searchResults4.htm")
	           .then().extract().response().asString();
		
		System.out.println(response);

	}

}
