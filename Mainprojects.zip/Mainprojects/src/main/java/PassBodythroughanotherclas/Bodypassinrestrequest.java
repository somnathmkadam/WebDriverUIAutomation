package PassBodythroughanotherclas;

public class Bodypassinrestrequest {
	
	public static String body() {
		String body= "appVersion=339&offset=10&isPaginated=true&sessionId=b73d13743966d9cd15856559148951993&firstTimeLocation=false&filterBy=&categoryName=city&checkInDate=23%2F05%2F2020&deviceId=b73d13743966d9cd&roomRequests%5B0%5D.noOfAdults=1&country.code=India&checkOutDate=24%2F05%2F2020&osVersion=28&propertyType=hotels&categoryValue=Bengaluru&country.name=India&roomRequests%5B0%5D.id=1"
				+ "&sortBy=&page=1&userType=GUEST&roomRequests%5B0%5D.noOfChildren=0&cameFromLastMinuteDeals=false&bookingMode";
		return body;
	}

}
