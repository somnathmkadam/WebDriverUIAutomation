package FetchResponseUsingPojoClass;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


public class pojoofresponse1 {
	
	private	String resCode;
    private String resMessage;
    private String interactionId;
    private String interationType;
    private String sessionId;
    private Response2 response;
	public String getResCode() {
		return resCode;
	}
	public void setResCode(String resCode) {
		this.resCode = resCode;
	}
	public String getResMessage() {
		return resMessage;
	}
	public void setResMessage(String resMessage) {
		this.resMessage = resMessage;
	}
	public String getInteractionId() {
		return interactionId;
	}
	public void setInteractionId(String interactionId) {
		this.interactionId = interactionId;
	}
	public String getInterationType() {
		return interationType;
	}
	public void setInterationType(String interationType) {
		this.interationType = interationType;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public Response2 getResponse() {
		return response;
	}
	public void setResponse(Response2 response) {
		this.response = response;
	}
    
	
	
}
