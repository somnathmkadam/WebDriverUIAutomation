package FetchResponseUsingPojoClass;

import static io.restassured.RestAssured.given;

import java.util.List;

import PassBodythroughanotherclas.Bodypassinrestrequest;
import io.restassured.RestAssured;
import io.restassured.parsing.Parser;

public class Restpassresponseinpojoclass {  //here response is passed in pojo class

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RestAssured.baseURI="https://secure.yatra.com/";
		
		pojoofresponse1 response = given().header("Device-Id","b73d13743966d9cd")
				 .header("yt-code","898cca20b1066c2621c4ee78d5f32850")
				.header("Parent-Interaction-Id","8ec43f34-6ef8-492d-bcf4-f5931fc1e4fe")
				.header("Connection","close")
				.header("User-Agent","yatra/13.0.95 (Android 9)")
				.header("App-Version","399")
	            .header("secure-s-token","1b99a635-f77f-4ff4-b35c-4870725e97a9")  
	            .header("Session-Id","b73f13743966d9cd15856541327545467")
	            .header("Content-Type","application/x-www-form-urlencoded")
	            .body(Bodypassinrestrequest.body()).expect().defaultParser(Parser.JSON)
	            .when().post("ccwebapp/mobile/hotel/mdomhotelandroid/searchResults4.htm").as(pojoofresponse1.class);
	            
		
		System.out.println(response.getInteractionId());
		System.out.println(response.getInterationType());
		System.out.println(response.getResCode());
		System.out.println(response.getResponse().getHotelsResponseTimeInMilis());
		System.out.println(response.getResponse().getSortType());
		System.out.println(response.getResponse().getYatraSmart().get(1).getLink());
		
		
		/*   to fetch data form array (int i=0; i<response.getResponse().getYatraSmart().size();i++) {
			
		}  OR use list object */
		
	  List <yatrasmartdetails3> Getyatrasmart= response.getResponse().getYatraSmart();	  
	  for (int i=0; i<Getyatrasmart.size();i++) {
		  System.out.println("output of reponse without link is \n");
		 if (Getyatrasmart.get(i).getLink()==null) {
			 System.out.println(Getyatrasmart.get(i).getId() + "\n"+ Getyatrasmart.get(i).getName());
			 
		 }
		 
		 else {
			 System.out.println("output of response with link is \n"+ Getyatrasmart.get(i).getId()+"\n" + Getyatrasmart.get(i).getLink() + "\n"+Getyatrasmart.get(i).getName());
		 }
		}
	
	}

}
