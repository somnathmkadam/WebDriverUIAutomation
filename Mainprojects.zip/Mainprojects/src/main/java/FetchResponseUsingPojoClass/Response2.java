package FetchResponseUsingPojoClass;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
public class Response2 {

	private String totalResultCount;
	private String status;
	private String hotelsResponseTimeInMilis;
	private String sortType;
	private List <yatrasmartdetails3> yatraSmart;
	
	
	
	public String getTotalResultCount() {
		return totalResultCount;
	}
	public void setTotalResultCount(String totalResultCount) {
		this.totalResultCount = totalResultCount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getHotelsResponseTimeInMilis() {
		return hotelsResponseTimeInMilis;
	}
	public void setHotelsResponseTimeInMilis(String hotelsResponseTimeInMilis) {
		this.hotelsResponseTimeInMilis = hotelsResponseTimeInMilis;
	}
	public String getSortType() {
		return sortType;
	}
	public void setSortType(String sortType) {
		this.sortType = sortType;
	}
	public List<FetchResponseUsingPojoClass.yatrasmartdetails3> getYatraSmart() {
		return yatraSmart;
	}
	public void setYatraSmart(List<FetchResponseUsingPojoClass.yatrasmartdetails3> yatraSmart) { 
		this.yatraSmart = yatraSmart;
	}

	
	
}
