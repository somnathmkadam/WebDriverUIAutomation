package com.flight.ExcelData;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelDataRead {

	public XSSFSheet initiateExcelConnection (){
		// TODO Auto-generated method stub
		XSSFWorkbook wb = null;
		FileInputStream fis = null;
		XSSFSheet sheet = null;
		try {
			
			fis = new FileInputStream("D:\\Mainproject\\Mainprojects\\FlightData.xlsx");
			wb = new XSSFWorkbook(fis);
			sheet = wb.getSheet("Sheet1");
		}
		catch (RuntimeException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return sheet;
	}
	

	}


