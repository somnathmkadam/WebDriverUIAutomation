package com.flight.ExcelData;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.ss.usermodel.CellType;


/*import org.apache.poi.hssf.eventusermodel.HSSFListener;
import org.apache.poi.hssf.record.chart.SheetPropertiesRecord;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;*/


@SuppressWarnings({ "rawtypes", "unused" })
public class Testdatagenerator {

	XSSFSheet sheet = null;
	ExcelDataRead readTestData = new ExcelDataRead();
	List<XSSFCell> sheetHeader = null;
	Object[][] array = null;
	public Object[][] getTestDataForSanityTest() throws Exception {
	
		sheet=	readTestData.initiateExcelConnection();
		List<List<XSSFCell>> sheetData = new ArrayList<List<XSSFCell>>();
		List<List<XSSFCell>> XSSFlistData = getData(sheet);
		sheetHeader = XSSFlistData.get(0);
		XSSFlistData.remove(0);
		array = getArray(XSSFlistData, sheetHeader);
	/*	for(int i=0;i<array.length;i++) {
			System.out.println(("array value is :\n")+Arrays.toString(array[i]));
		}*/
		return array;
		
	}
	
	
	
	
	
	public static List<List<XSSFCell>> getData(XSSFSheet sheet) {
		List<List<XSSFCell>> sheetData = new ArrayList<List<XSSFCell>>();
		try {
			Iterator<Row> rows = sheet.rowIterator();

			while (rows.hasNext()) {
				XSSFRow rown = (XSSFRow) rows.next();
				Iterator<Cell> cells = rown.cellIterator();

				List<XSSFCell> data = new ArrayList<XSSFCell>();
				while (cells.hasNext()) {
					XSSFCell celln = (XSSFCell) cells.next();
					celln = (XSSFCell) castCellType(celln);
					data.add(celln);
				}
				sheetData.add(data);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		return sheetData;
	}
	
	public static Cell castCellType(Cell cell) {
	//	cell.getCellType().NUMERIC
		
		
		
		if (cell.getCellType() == CellType.NUMERIC) {
			if (DateUtil.isCellDateFormatted(cell)) {
				cell.setCellType(CellType.NUMERIC);
			} else
				cell.setCellType(CellType.STRING);
		} else if (cell.getCellType() == CellType.STRING) {
			cell.getRichStringCellValue();
		} else if (cell.getCellType() == CellType.FORMULA) {
			cell.setCellType(CellType.STRING);
		} else if (cell.getCellType() == CellType.BLANK) {
			cell.setCellType(CellType.STRING);
		} else if (cell.getCellType() == CellType.BOOLEAN) {
			cell.setCellType(CellType.STRING);
		} else if (cell.getCellType() == CellType.ERROR) {
			cell.setCellType(CellType.STRING);
		}
		return cell;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public Object[][] getArray(List<List<XSSFCell>> sheetData, List<XSSFCell> headers) {

		int indYN = getIndexFromSheetHeaderList("Yes/No");
		Iterator<List<XSSFCell>> checkData = sheetData.iterator();
		List<List<String>> list = new ArrayList<List<String>>();
		List<String> temp, list1 = null;
		List<XSSFCell> oneDList = null;
		while (checkData.hasNext()) {
			oneDList = (List<XSSFCell>) checkData.next();
			if (oneDList.get(indYN).toString().equals("Yes")){
				list1 = new ArrayList<String>();
			for (int i = 0; i < oneDList.size(); i++) {
				list1.add(headers.get(i).toString() + "_" + oneDList.get(i).toString());
			}
			list.add(list1);
		}
		}
		Object[][] result = new Object[list.size()][];
		try {
			for (int i = 0; i < result.length; i++) {
				result[i] = new Object[] { list.get(i) };
			}
		} catch (Exception ex) {
		}
		return result;
	}
	
	public int getIndexFromSheetHeaderList(String hdrColName) {  // check at which place yes/no is present
		Iterator<XSSFCell> hdrItr = sheetHeader.iterator();
		XSSFCell hdrVal = null;
		int indOfCol = 0;
		while (hdrItr.hasNext()) {
			hdrVal = hdrItr.next();
			if (hdrVal.toString().trim().equals(hdrColName))
				indOfCol = sheetHeader.indexOf((Object) hdrVal);
		}
		return indOfCol;

	}





	// This Method used to convert Array into Linked hash map  
		public static HashMap<String, String> getHashMap(List data) {

			HashMap<String, String> testdata = new LinkedHashMap<String, String>();
			for (int i = 0; i < data.size(); i++) {
				String[] temp = data.get(i).toString().split("_");  //TestName_FlightSearch separted by _ and stored in temp ["TestName": "lightSearch"]

				if (temp.length == 1)
					testdata.put(temp[0], "");   //If value is null then set blank ""
				else
					testdata.put(temp[0], temp[1]);
			}
			return testdata;
		}
	
	
}
