package com.flight.ExcelData;

import java.util.HashMap;

public class BaseTest {
	public HashMap<String , String> HashMapData = new HashMap<String , String>();
	
}
