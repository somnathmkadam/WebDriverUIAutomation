package GoogleSheetDataRead;

import org.testng.ITestContext;
import org.testng.annotations.DataProvider;



public class DataProviderClass {
	
	@DataProvider (name="Dataprovider")
    public static Object [][] data(ITestContext data){  //data is method
 	   //public static type and name of dataprovider class
 	//   ITestContext: gives information of dataprovider class to run the test from testng file
 	   
 	   String sheetname, datadriver, workbook, spreadsheetID;
 	   Object [][] srpdata = null; //set object array to null
 	   
 	   sheetname= data.getCurrentXmlTest().getParameter("sheet"); //stored data from testng file to string
 	   datadriver= data.getCurrentXmlTest().getParameter("DataDriver");
 	   workbook = data.getCurrentXmlTest().getParameter("workBookName");
 	   spreadsheetID = data.getCurrentXmlTest().getParameter("spreadsheetId");
 	  TestDataGenerator testdata = new TestDataGenerator(workbook, sheetname, datadriver, spreadsheetID);
 	  //TestDataGenerator is parameterize constructor and we passed value to this constructor which used for further process
 	  System.out.println("hello");
 	  try {
 		 srpdata=  testdata.gettestdataforsanity();
 		  
 	  }catch (Exception e) {
 		  e.printStackTrace();
 	  }
 	   
 	   return srpdata;
 	
    }
    

}
