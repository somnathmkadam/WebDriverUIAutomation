package ReadDataFromConfiq;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;

public class ReadDataConfiq {

	private Properties loadProperties() {
		File file = new File("D:\\Mainproject\\Mainprojects\\src\\main\\resources\\confiq.properties");
		FileInputStream fileInput = null;
		Properties props = new Properties();
		

		try {
			fileInput = new FileInputStream(file);
			props.load(fileInput);
			fileInput.close();
		} catch (FileNotFoundException e) {
		
		} catch (IOException e) {
			
		}

		return props;
	}
	
	private static Properties properties;
	@Test
	public ReadDataConfiq(){
		properties =  loadProperties();
		
		System.out.println("output is.................\n" +properties.getProperty("ecashLogin"));
	}
	
}
