package FetchDataFromFile;



import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static io.restassured.RestAssured.given;


public class BodyDatafromFile {

	@Test
	public static void  Bodyfetch() throws IOException {
	
		
	
		
		RestAssured.baseURI="https://secure.yatra.com/";
		
		String response1 = given().header("Device-Id","b73d13743966d9cd")
				 .header("yt-code","898cca20b1066c2621c4ee78d5f32850")
				.header("Parent-Interaction-Id","8ec43f34-6ef8-492d-bcf4-f5931fc1e4fe")
				.header("Connection","close")
				.header("User-Agent","yatra/13.0.95 (Android 9)")
				.header("App-Version","399")
	           .header("secure-s-token","1b99a635-f77f-4ff4-b35c-4870725e97a9")  
	           .header("Session-Id","b73f13743966d9cd15856541327545467")
	           .header("Content-Type","application/x-www-form-urlencoded")
	           .body(GenerateStringFromResource("D:\\Mainproject\\Mainprojects\\file1.txt"))
	           .when().post("ccwebapp/mobile/hotel/mdomhotelandroid/searchResults4.htm")
	           .then().extract().response().asString();
		
	 System.out.println(response1);	
	}
	
	
	public static String GenerateStringFromResource(String path) throws IOException {
		return new String (Files.readAllBytes(Paths.get(path)));
	}

}
